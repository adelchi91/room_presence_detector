from api_gateway.models.validators.smirky_beaver import FinalModel  # NOQA
